-- Backup do Banco de Dados
-- Gerado em: 2026-06-12 11:29:43
-- Empresa ID: 0

SET FOREIGN_KEY_CHECKS=0;


-- Estrutura da tabela `assinatura_log`
DROP TABLE IF EXISTS `assinatura_log`;
CREATE TABLE `assinatura_log` (
  `id` int(11) NOT NULL,
  `assinatura_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) NOT NULL,
  `acao` varchar(50) NOT NULL,
  `detalhes` text,
  `ip` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados da tabela `assinatura_log`

-- Estrutura da tabela `assinaturas`
DROP TABLE IF EXISTS `assinaturas`;
CREATE TABLE `assinaturas` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `plano_id` int(11) NOT NULL,
  `status` enum('ativa','cancelada','suspensa','teste') COLLATE utf8mb4_unicode_ci DEFAULT 'ativa',
  `data_inicio` date NOT NULL,
  `data_fim` date DEFAULT NULL,
  `ciclo` enum('mensal','anual') COLLATE utf8mb4_unicode_ci DEFAULT 'mensal',
  `valor` decimal(10,2) NOT NULL,
  `forma_pagamento` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pagamento_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancelado_em` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `assinaturas`
INSERT INTO `assinaturas` (`id`, `empresa_id`, `plano_id`, `status`, `data_inicio`, `data_fim`, `ciclo`, `valor`, `forma_pagamento`, `pagamento_id`, `cancelado_em`, `created_at`, `updated_at`) VALUES ('0', '0', '2', 'ativa', '2026-06-10', NULL, 'mensal', '89.00', NULL, NULL, NULL, '2026-06-10 18:43:31', '2026-06-10 18:43:31');


-- Estrutura da tabela `auditoria_config`
DROP TABLE IF EXISTS `auditoria_config`;
CREATE TABLE `auditoria_config` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `logar_login` bit(1) DEFAULT b'1',
  `logar_logout` bit(1) DEFAULT b'1',
  `logar_insert` bit(1) DEFAULT b'1',
  `logar_update` bit(1) DEFAULT b'1',
  `logar_delete` bit(1) DEFAULT b'1',
  `logar_view` bit(1) DEFAULT b'0',
  `dias_retencao` int(11) DEFAULT '90',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados da tabela `auditoria_config`

-- Estrutura da tabela `autorizacoes_ponto`
DROP TABLE IF EXISTS `autorizacoes_ponto`;
CREATE TABLE `autorizacoes_ponto` (
  `id` int(11) NOT NULL,
  `funcionario_id` int(11) NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `latitude` varchar(50) DEFAULT NULL,
  `longitude` varchar(50) DEFAULT NULL,
  `token` varchar(255) NOT NULL,
  `status` enum('pendente','aprovado','rejeitado') DEFAULT 'pendente',
  `autorizado_por` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados da tabela `autorizacoes_ponto`

-- Estrutura da tabela `backups_config`
DROP TABLE IF EXISTS `backups_config`;
CREATE TABLE `backups_config` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `backup_automatico` bit(1) DEFAULT b'1',
  `frequencia` enum('diario','semanal','mensal') DEFAULT 'diario',
  `hora_backup` time DEFAULT '02:00:00',
  `dias_retencao` int(11) DEFAULT '30',
  `incluir_uploads` bit(1) DEFAULT b'1',
  `notificar_email` bit(1) DEFAULT b'0',
  `email_notificacao` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados da tabela `backups_config`
INSERT INTO `backups_config` (`id`, `empresa_id`, `backup_automatico`, `frequencia`, `hora_backup`, `dias_retencao`, `incluir_uploads`, `notificar_email`, `email_notificacao`, `created_at`, `updated_at`) VALUES ('0', '0', '1', 'diario', '02:00:00', '30', '1', '0', NULL, '2026-06-12 11:29:17', '2026-06-12 11:29:17');


-- Estrutura da tabela `backups_registros`
DROP TABLE IF EXISTS `backups_registros`;
CREATE TABLE `backups_registros` (
  `id` int(11) NOT NULL,
  `nome_arquivo` varchar(255) NOT NULL,
  `tamanho` varchar(50) DEFAULT NULL,
  `tipo` enum('manual','automatico','agendado') DEFAULT 'manual',
  `status` enum('sucesso','falha') DEFAULT 'sucesso',
  `mensagem_erro` text,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados da tabela `backups_registros`
INSERT INTO `backups_registros` (`id`, `nome_arquivo`, `tamanho`, `tipo`, `status`, `mensagem_erro`, `created_by`, `created_at`) VALUES ('1', 'backup_2026-05-18_19-31-33.sql.gz', '12.17 KB', 'manual', 'sucesso', NULL, '8', '2026-05-18 14:31:34');


-- Estrutura da tabela `banco_horas`
DROP TABLE IF EXISTS `banco_horas`;
CREATE TABLE `banco_horas` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `funcionario_id` int(11) NOT NULL,
  `saldo_minutos` int(11) DEFAULT '0',
  `horas_extras_50` int(11) DEFAULT '0',
  `horas_extras_100` int(11) DEFAULT '0',
  `faltas_minutos` int(11) DEFAULT '0',
  `mes_referencia` date NOT NULL,
  `observacao` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `banco_horas`

-- Estrutura da tabela `biometricos_digitais`
DROP TABLE IF EXISTS `biometricos_digitais`;
CREATE TABLE `biometricos_digitais` (
  `id` int(11) NOT NULL,
  `funcionario_id` int(11) NOT NULL,
  `digital_template` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `digital_formato` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'ISO_19794_2',
  `ativo` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `biometricos_digitais`

-- Estrutura da tabela `biometricos_faciais`
DROP TABLE IF EXISTS `biometricos_faciais`;
CREATE TABLE `biometricos_faciais` (
  `id` int(11) NOT NULL,
  `funcionario_id` int(11) NOT NULL,
  `descritores` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `modelo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'face-api.js',
  `ativo` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `biometricos_faciais`

-- Estrutura da tabela `cargos`
DROP TABLE IF EXISTS `cargos`;
CREATE TABLE `cargos` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `salario_base` decimal(10,2) DEFAULT NULL,
  `nivel` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `cargos`
INSERT INTO `cargos` (`id`, `nome`, `descricao`, `salario_base`, `nivel`, `ativo`, `created_at`) VALUES ('1', 'Administrador', 'Administrador do Sistema', '8000.00', NULL, '1', '2026-04-19 13:31:46'),
('2', 'Gerente', 'Gerente de Filial', '6000.00', NULL, '1', '2026-04-19 13:31:46'),
('3', 'Supervisor', 'Supervisor de Equipe', '4500.00', NULL, '1', '2026-04-19 13:31:46'),
('4', 'Analista', 'Analista de Sistemas', '4000.00', NULL, '1', '2026-04-19 13:31:46'),
('5', 'Vendedor', 'Vendedor', '2500.00', NULL, '1', '2026-04-19 13:31:46'),
('6', 'Atendente', 'Atendente', '2200.00', NULL, '1', '2026-04-19 13:31:46'),
('7', 'Auxiliar', 'Auxiliar Administrativo', '2000.00', NULL, '1', '2026-04-19 13:31:46');


-- Estrutura da tabela `config_email`
DROP TABLE IF EXISTS `config_email`;
CREATE TABLE `config_email` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `smtp_host` varchar(100) DEFAULT 'smtp.gmail.com',
  `smtp_port` int(11) DEFAULT '587',
  `smtp_user` varchar(100) DEFAULT NULL,
  `smtp_password` varchar(255) DEFAULT NULL,
  `smtp_secure` enum('tls','ssl') DEFAULT 'tls',
  `email_remetente` varchar(100) DEFAULT NULL,
  `nome_remetente` varchar(100) DEFAULT NULL,
  `notificacoes_ativas` bit(1) DEFAULT b'0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados da tabela `config_email`
INSERT INTO `config_email` (`id`, `empresa_id`, `smtp_host`, `smtp_port`, `smtp_user`, `smtp_password`, `smtp_secure`, `email_remetente`, `nome_remetente`, `notificacoes_ativas`, `created_at`, `updated_at`) VALUES ('0', '0', 'smtp.gmail.com', '587', NULL, NULL, 'tls', NULL, NULL, '0', '2026-06-11 10:12:30', '2026-06-11 10:12:30');


-- Estrutura da tabela `config_empresa`
DROP TABLE IF EXISTS `config_empresa`;
CREATE TABLE `config_empresa` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `nome_empresa` varchar(200) DEFAULT NULL,
  `cnpj` varchar(18) DEFAULT NULL,
  `inscricao_estadual` varchar(20) DEFAULT NULL,
  `inscricao_municipal` varchar(20) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `site` varchar(100) DEFAULT NULL,
  `endereco` varchar(200) DEFAULT NULL,
  `numero` varchar(20) DEFAULT NULL,
  `complemento` varchar(100) DEFAULT NULL,
  `bairro` varchar(100) DEFAULT NULL,
  `cidade` varchar(100) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL,
  `cep` varchar(10) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados da tabela `config_empresa`
INSERT INTO `config_empresa` (`id`, `empresa_id`, `nome_empresa`, `cnpj`, `inscricao_estadual`, `inscricao_municipal`, `telefone`, `email`, `site`, `endereco`, `numero`, `complemento`, `bairro`, `cidade`, `estado`, `cep`, `logo`, `created_at`, `updated_at`) VALUES ('0', '0', 'Silmar Rodrigues Junior', '14.838.380/0001-42', '', '', '(21) 97556-6267', 'silmar_jr@yahoo.com.br', '', 'Rua Alfredo Rebello Filho', '452', 'Loja C', 'Alto', 'Teresópolis', 'RJ', '25959215', NULL, '2026-06-11 10:08:07', '2026-06-11 10:10:26');


-- Estrutura da tabela `config_excecoes_horario`
DROP TABLE IF EXISTS `config_excecoes_horario`;
CREATE TABLE `config_excecoes_horario` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `data` date NOT NULL,
  `descricao` varchar(200) DEFAULT NULL,
  `entrada` time DEFAULT NULL,
  `saida_almoco` time DEFAULT NULL,
  `volta_almoco` time DEFAULT NULL,
  `saida` time DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados da tabela `config_excecoes_horario`
INSERT INTO `config_excecoes_horario` (`id`, `empresa_id`, `data`, `descricao`, `entrada`, `saida_almoco`, `volta_almoco`, `saida`, `created_at`) VALUES ('0', '0', '2026-06-12', 'Horário Normal', '09:00:00', '13:00:00', '14:00:00', '18:00:00', '2026-06-12 11:04:55');


-- Estrutura da tabela `config_facial`
DROP TABLE IF EXISTS `config_facial`;
CREATE TABLE `config_facial` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `facial_obrigatorio` bit(1) DEFAULT b'1',
  `confianca_minima` int(11) DEFAULT '70',
  `tentativas_maximas` int(11) DEFAULT '3',
  `permitir_fallback` bit(1) DEFAULT b'1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `qualidade_imagem` bit(1) DEFAULT b'1',
  `detectar_expressao` bit(1) DEFAULT b'0',
  `validar_vivo` bit(1) DEFAULT b'0',
  `tempo_maximo_captura` int(11) DEFAULT '30',
  `zoom_automatico` bit(1) DEFAULT b'1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados da tabela `config_facial`
INSERT INTO `config_facial` (`id`, `empresa_id`, `facial_obrigatorio`, `confianca_minima`, `tentativas_maximas`, `permitir_fallback`, `created_at`, `updated_at`, `qualidade_imagem`, `detectar_expressao`, `validar_vivo`, `tempo_maximo_captura`, `zoom_automatico`) VALUES ('0', '0', '1', '70', '3', '1', '2026-06-11 10:13:27', '2026-06-11 10:13:27', '1', '0', '0', '30', '1');


-- Estrutura da tabela `config_feriados`
DROP TABLE IF EXISTS `config_feriados`;
CREATE TABLE `config_feriados` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `data` date NOT NULL,
  `nome` varchar(100) NOT NULL,
  `tipo` enum('nacional','estadual','municipal','pontofacultativo') DEFAULT 'nacional',
  `abonado` bit(1) DEFAULT b'1',
  `observacao` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados da tabela `config_feriados`
INSERT INTO `config_feriados` (`id`, `empresa_id`, `data`, `nome`, `tipo`, `abonado`, `observacao`, `created_at`) VALUES ('0', '0', '2026-01-01', 'Confraternização Universal', 'nacional', '1', '', '2026-06-12 08:58:42'),
('0', '0', '2026-02-17', 'Carnaval', 'nacional', '1', '', '2026-06-12 08:59:11'),
('0', '0', '2026-04-03', 'Sexta Feira Santa', 'nacional', '1', '', '2026-06-12 08:59:57'),
('0', '0', '2026-04-21', 'Tiradentes', 'nacional', '1', '', '2026-06-12 09:00:18'),
('0', '0', '2026-04-23', 'São Jorge', 'estadual', '1', '', '2026-06-12 09:00:46'),
('0', '0', '2026-05-01', 'Dia do Trabalhador', 'nacional', '1', '', '2026-06-12 09:01:32'),
('0', '0', '2026-06-04', 'Corpus Christi', 'nacional', '1', '', '2026-06-12 09:08:26'),
('0', '0', '2026-06-13', 'Santo  Antônio', 'estadual', '1', '', '2026-06-12 09:09:15'),
('0', '0', '2026-07-06', 'Aniversário de Teresópolis', 'municipal', '1', '', '2026-06-12 09:09:54'),
('0', '0', '2026-09-07', 'Independência do Brasil', 'nacional', '1', '', '2026-06-12 09:10:40'),
('0', '0', '2026-10-12', 'Nossa Senhora Aparecida', 'nacional', '1', '', '2026-06-12 09:11:23'),
('0', '0', '2026-10-15', 'Santa Teresa', 'municipal', '1', '', '2026-06-12 09:11:55'),
('0', '0', '2026-11-02', 'Finados', 'nacional', '1', '', '2026-06-12 09:12:35'),
('0', '0', '2026-11-15', 'Proclamação da República', 'nacional', '1', '', '2026-06-12 09:13:02'),
('0', '0', '2026-11-20', 'Dia da Consciência Negra', 'estadual', '1', '', '2026-06-12 09:13:38'),
('0', '0', '2026-12-25', 'Natal', 'nacional', '1', '', '2026-06-12 09:13:58');


-- Estrutura da tabela `config_horarios`
DROP TABLE IF EXISTS `config_horarios`;
CREATE TABLE `config_horarios` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `horario_entrada` time DEFAULT '08:00:00',
  `horario_saida_almoco` time DEFAULT '12:00:00',
  `horario_volta_almoco` time DEFAULT '13:00:00',
  `horario_saida` time DEFAULT '17:00:00',
  `tolerancia_entrada` int(11) DEFAULT '5',
  `tolerancia_saida` int(11) DEFAULT '5',
  `carga_horaria_diaria` int(11) DEFAULT '8',
  `carga_horaria_semanal` int(11) DEFAULT '44',
  `horas_extras_50` bit(1) DEFAULT b'1',
  `horas_extras_100` bit(1) DEFAULT b'1',
  `desconto_atraso` bit(1) DEFAULT b'1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `permitir_hora_negativa` bit(1) DEFAULT b'0',
  `justificativa_obrigatoria` bit(1) DEFAULT b'0',
  `bloquear_ponto_fora_horario` bit(1) DEFAULT b'0',
  `permitir_ponto_remoto` bit(1) DEFAULT b'1',
  `validar_gps` bit(1) DEFAULT b'0',
  `facial_obrigatorio` bit(1) DEFAULT b'0',
  `intervalo_minimo_almoco` int(11) DEFAULT '60',
  `intervalo_maximo_almoco` int(11) DEFAULT '120',
  `tempo_minimo_entrada` int(11) DEFAULT '30',
  `dias_para_justificar` int(11) DEFAULT '7'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados da tabela `config_horarios`
INSERT INTO `config_horarios` (`id`, `empresa_id`, `horario_entrada`, `horario_saida_almoco`, `horario_volta_almoco`, `horario_saida`, `tolerancia_entrada`, `tolerancia_saida`, `carga_horaria_diaria`, `carga_horaria_semanal`, `horas_extras_50`, `horas_extras_100`, `desconto_atraso`, `created_at`, `updated_at`, `permitir_hora_negativa`, `justificativa_obrigatoria`, `bloquear_ponto_fora_horario`, `permitir_ponto_remoto`, `validar_gps`, `facial_obrigatorio`, `intervalo_minimo_almoco`, `intervalo_maximo_almoco`, `tempo_minimo_entrada`, `dias_para_justificar`) VALUES ('0', '0', '07:30:00', '12:00:00', '13:00:00', '20:00:00', '10', '10', '8', '44', '1', '1', '1', '2026-06-11 10:10:32', '2026-06-12 11:27:53', '1', '1', '1', '1', '1', '1', '60', '120', '30', '7');


-- Estrutura da tabela `configuracoes`
DROP TABLE IF EXISTS `configuracoes`;
CREATE TABLE `configuracoes` (
  `id` int(11) NOT NULL,
  `chave` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` text COLLATE utf8mb4_unicode_ci,
  `tipo` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'texto',
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `grupo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `configuracoes`
INSERT INTO `configuracoes` (`id`, `chave`, `valor`, `tipo`, `descricao`, `grupo`, `created_at`, `updated_at`) VALUES ('1', 'sistema_nome', 'Ponto Fácil Empresarial', 'texto', 'Nome do sistema', 'geral', '2026-04-19 13:31:46', '2026-04-19 13:31:46'),
('2', 'sistema_versao', '1.0.0', 'texto', 'Versão do sistema', 'geral', '2026-04-19 13:31:46', '2026-04-19 13:31:46'),
('3', 'ponto_tolerancia', '5', 'numero', 'Minutos de tolerância', 'ponto', '2026-04-19 13:31:46', '2026-04-19 13:31:46'),
('4', 'ponto_offline_ativo', '1', 'booleano', 'Permite ponto offline', 'ponto', '2026-04-19 13:31:46', '2026-04-19 13:31:46'),
('5', 'notificacao_email', '1', 'booleano', 'Enviar notificações por email', 'notificacoes', '2026-04-19 13:31:46', '2026-04-19 13:31:46'),
('6', 'horario_minimo', '06:00:00', 'hora', 'Horário mínimo para bater ponto', 'ponto', '2026-04-19 13:31:46', '2026-04-19 13:31:46'),
('7', 'horario_maximo', '22:00:00', 'hora', 'Horário máximo para bater ponto', 'ponto', '2026-04-19 13:31:46', '2026-04-19 13:31:46'),
('8', 'biometrico_ativado', '1', 'booleano', 'Ativar reconhecimento facial', 'biometrico', '2026-04-26 19:32:14', '2026-04-26 19:32:14'),
('9', 'biometrico_limiar', '0.6', 'decimal', 'Limiar de similaridade (0-1)', 'biometrico', '2026-04-26 19:32:14', '2026-04-26 19:32:14'),
('10', 'biometrico_amostras', '5', 'numero', 'Número de amostras para cadastro', 'biometrico', '2026-04-26 19:32:14', '2026-04-26 19:32:14'),
('11', 'biometrico_tipo', 'ambos', 'texto', 'Tipo de biometria: digital, facial, ambos', 'biometrico', '2026-04-26 19:34:11', '2026-04-26 19:34:11'),
('12', 'biometrico_limiar_facial', '0.6', 'decimal', 'Limiar de similaridade facial (0-1)', 'biometrico', '2026-04-26 19:34:11', '2026-04-26 19:34:11'),
('13', 'biometrico_amostras_faciais', '5', 'numero', 'Número de amostras faciais para cadastro', 'biometrico', '2026-04-26 19:34:11', '2026-04-26 19:34:11'),
('14', 'biometrico_validade_dias', '365', 'numero', 'Validade da biometria em dias', 'biometrico', '2026-04-26 19:34:11', '2026-04-26 19:34:11');


-- Estrutura da tabela `departamentos`
DROP TABLE IF EXISTS `departamentos`;
CREATE TABLE `departamentos` (
  `id` int(11) NOT NULL,
  `filial_id` int(11) NOT NULL,
  `nome` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `responsavel_id` int(11) DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `departamentos`
INSERT INTO `departamentos` (`id`, `filial_id`, `nome`, `codigo`, `descricao`, `responsavel_id`, `ativo`, `created_at`) VALUES ('1', '1', 'Administrativo', 'ADM', NULL, NULL, '1', '2026-04-19 13:31:46'),
('2', '1', 'Tecnologia', 'TI', NULL, NULL, '1', '2026-04-19 13:31:46'),
('3', '1', 'Comercial', 'COM', NULL, NULL, '1', '2026-04-19 13:31:46'),
('4', '2', 'Vendas', 'VEN', NULL, NULL, '1', '2026-04-19 13:31:46'),
('5', '2', 'Atendimento', 'ATE', NULL, NULL, '1', '2026-04-19 13:31:46'),
('6', '3', 'Logística', 'LOG', NULL, NULL, '1', '2026-04-19 13:31:46'),
('7', '4', 'Financeiro', 'FIN', NULL, NULL, '1', '2026-04-19 13:31:46');


-- Estrutura da tabela `empresa`
DROP TABLE IF EXISTS `empresa`;
CREATE TABLE `empresa` (
  `id` int(11) NOT NULL,
  `nome_empresa` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `razao_social` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnpj` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inscricao_estadual` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_contato` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco` text COLLATE utf8mb4_unicode_ci,
  `cidade` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `empresa`
INSERT INTO `empresa` (`id`, `nome_empresa`, `razao_social`, `cnpj`, `inscricao_estadual`, `logo`, `email_contato`, `telefone`, `endereco`, `cidade`, `estado`, `cep`, `site`, `created_at`, `updated_at`) VALUES ('1', 'Empresa Principal', 'Ponto Fácil Sistemas Ltda', '12.345.678/0001-90', NULL, NULL, 'contato@pontofacil.com', '(11) 99999-9999', NULL, NULL, NULL, NULL, NULL, '2026-04-19 13:31:46', '2026-05-05 12:10:04'),
('2', 'Empresa Zona Norte', NULL, '00.000.000/0002-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-05-05 15:15:40', '2026-05-05 15:15:40'),
('3', 'Empresa Zona Sul', NULL, '00.000.000/0003-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-05-05 15:15:40', '2026-05-05 15:15:40'),
('4', 'Empresa Alphaville', NULL, '00.000.000/0004-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-05-05 15:15:40', '2026-05-05 15:15:40'),
('5', 'Empresa Divulgonline', NULL, '00.000.000/0000-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-05-05 15:02:32', '2026-05-05 15:15:40'),
('6', 'Empresa By Bicos', NULL, '00.000.000/0006-00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-05-05 15:15:40', '2026-05-05 15:15:40'),
('0', 'Empresa 0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-12 08:42:20', '2026-06-12 08:42:20');


-- Estrutura da tabela `empresas`
DROP TABLE IF EXISTS `empresas`;
CREATE TABLE `empresas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cnpj` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco` text COLLATE utf8mb4_unicode_ci,
  `cidade` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dominio` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('ativa','inativa','suspensa','teste') COLLATE utf8mb4_unicode_ci DEFAULT 'ativa',
  `data_ativacao` date DEFAULT NULL,
  `data_expiracao` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `cep` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `empresas`
INSERT INTO `empresas` (`id`, `nome`, `cnpj`, `email`, `telefone`, `endereco`, `cidade`, `estado`, `logo`, `dominio`, `status`, `data_ativacao`, `data_expiracao`, `created_at`, `updated_at`, `cep`, `numero`, `complemento`, `bairro`) VALUES ('1', 'Empresa Principal', '00.000.000/0001-00', 'admin@pontofacil.com', NULL, NULL, NULL, NULL, NULL, 'empresa', 'ativa', '2026-04-24', NULL, '2026-04-24 09:35:50', '2026-04-24 09:35:50', NULL, NULL, NULL, NULL),
('4', 'Divulgonline', NULL, 'divulgonlinebrasil@gmail.com', '21993678754', 'Rua Estado do Rio de Janeiro', 'Teresópolis', 'RJ', NULL, 'divulgonline', 'ativa', '2026-04-28', NULL, '2026-04-28 09:28:11', '2026-04-29 16:24:45', '25958-230', '330', 'Casa 11', 'Araras'),
('5', 'Empresa Teste', NULL, 'atendimento@bybicos.com.br', '(21) 99303-5049', 'Rua Estado do Rio de Janeiro', 'Teresópolis', 'RJ', NULL, 'bybicos', 'ativa', '2026-04-29', NULL, '2026-04-29 16:41:27', '2026-05-05 14:58:57', '25958-230', '330', 'Casa 11', 'Araras'),
('9', 'Teste', NULL, 'teste@empresa.com.br', '', 'Rua Beira Linha', 'Teresópolis', 'RJ', NULL, NULL, 'ativa', '2026-04-30', NULL, '2026-04-30 11:34:14', '2026-04-30 16:45:42', '25957-030', '540', '', 'Cascata Guarani'),
('10', 'Silmar Rodrigues Junior', '14.838.380/0001-42', 'silmar_jr@yahoo.com.br', '(21) 97556-6267', 'Rua Alfredo Rebello Filho', 'Teresópolis', 'RJ', NULL, 'junior', 'ativa', '2026-06-10', NULL, '2026-06-10 18:43:31', '2026-06-10 18:43:31', '25959-215', '452', 'Loja C', 'Alto');


-- Estrutura da tabela `empresas_excluidas`
DROP TABLE IF EXISTS `empresas_excluidas`;
CREATE TABLE `empresas_excluidas` (
  `id` int(11) NOT NULL,
  `empresa_original_id` int(11) DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `cnpj` varchar(18) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `motivo` text,
  `excluido_por` int(11) DEFAULT NULL,
  `data_exclusao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dados_json` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados da tabela `empresas_excluidas`

-- Estrutura da tabela `escala_diaria`
DROP TABLE IF EXISTS `escala_diaria`;
CREATE TABLE `escala_diaria` (
  `id` int(11) NOT NULL,
  `funcionario_id` int(11) NOT NULL,
  `data` date NOT NULL,
  `turno` enum('manha','tarde','noite','integral','plantao') NOT NULL,
  `observacao` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados da tabela `escala_diaria`

-- Estrutura da tabela `escala_dias`
DROP TABLE IF EXISTS `escala_dias`;
CREATE TABLE `escala_dias` (
  `id` int(11) NOT NULL,
  `escala_tipo_id` int(11) NOT NULL,
  `dia_semana` tinyint(1) NOT NULL COMMENT '1=Dom,2=Seg,3=Ter,4=Qua,5=Qui,6=Sex,7=Sáb',
  `tipo_dia` enum('trabalho','descanso','meio_periodo','feriado') COLLATE utf8mb4_unicode_ci DEFAULT 'trabalho',
  `horario_entrada` time DEFAULT NULL,
  `horario_saida` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `escala_dias`

-- Estrutura da tabela `escala_tipos`
DROP TABLE IF EXISTS `escala_tipos`;
CREATE TABLE `escala_tipos` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `nome` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('5x2','6x1','12x36','plantao','custom') COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `dias_trabalho` int(11) DEFAULT '5',
  `dias_descanso` int(11) DEFAULT '2',
  `carga_horaria_diaria` decimal(5,2) DEFAULT '8.00',
  `ativo` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `escala_tipos`

-- Estrutura da tabela `filiais`
DROP TABLE IF EXISTS `filiais`;
CREATE TABLE `filiais` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) NOT NULL,
  `codigo` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome_fantasia` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `razao_social` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnpj` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inscricao_estadual` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_ramo` enum('matriz','filial','loja','deposito','escritorio') COLLATE utf8mb4_unicode_ci DEFAULT 'filial',
  `segmento` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `responsavel_nome` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `responsavel_email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `responsavel_telefone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco` text COLLATE utf8mb4_unicode_ci,
  `numero` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `raio_permitido` int(11) DEFAULT '100',
  `tolerancia_minutos` int(11) DEFAULT '5',
  `horario_abertura` time DEFAULT NULL,
  `horario_fechamento` time DEFAULT NULL,
  `dias_funcionamento` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'segunda_sexta',
  `ativo` tinyint(1) DEFAULT '1',
  `observacao` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `filiais`
INSERT INTO `filiais` (`id`, `empresa_id`, `codigo`, `nome_fantasia`, `razao_social`, `cnpj`, `inscricao_estadual`, `tipo_ramo`, `segmento`, `responsavel_nome`, `responsavel_email`, `responsavel_telefone`, `endereco`, `numero`, `complemento`, `bairro`, `cidade`, `estado`, `cep`, `latitude`, `longitude`, `raio_permitido`, `tolerancia_minutos`, `horario_abertura`, `horario_fechamento`, `dias_funcionamento`, `ativo`, `observacao`, `created_at`, `updated_at`, `deleted_at`) VALUES ('22', '0', 'FP001', 'ELY SANTOS RODRIGUES', 'Micro Empresa', '24.957.774/0001-73', NULL, 'filial', '47.61-0-03 - Comércio varejista de artigos de pape', 'BIANCA ROCHA CUNHA', 'empresa@elysantos.com.br', '(21) 97556-6267', 'Rua Alfredo Rebello Filho', '452', 'Loja C', 'Alto', 'Teresópolis', 'RJ', '25959-215', NULL, NULL, '100', '10', '07:30:00', '20:00:00', 'todos_dias', '1', NULL, '2026-06-12 08:55:32', '2026-06-12 08:55:32', NULL);


-- Estrutura da tabela `funcionario_escala`
DROP TABLE IF EXISTS `funcionario_escala`;
CREATE TABLE `funcionario_escala` (
  `id` int(11) NOT NULL,
  `funcionario_id` int(11) NOT NULL,
  `escala_tipo_id` int(11) NOT NULL,
  `data_inicio` date NOT NULL,
  `data_fim` date DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `funcionario_escala`

-- Estrutura da tabela `funcionario_jornada`
DROP TABLE IF EXISTS `funcionario_jornada`;
CREATE TABLE `funcionario_jornada` (
  `id` int(11) NOT NULL,
  `funcionario_id` int(11) NOT NULL,
  `jornada_id` int(11) NOT NULL,
  `data_inicio` date NOT NULL,
  `data_fim` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `funcionario_jornada`
INSERT INTO `funcionario_jornada` (`id`, `funcionario_id`, `jornada_id`, `data_inicio`, `data_fim`, `created_at`) VALUES ('1', '2', '1', '2024-01-15', NULL, '2026-04-19 13:31:46'),
('2', '3', '3', '2024-02-01', NULL, '2026-04-19 13:31:46'),
('3', '4', '4', '2024-02-15', NULL, '2026-04-19 13:31:46'),
('4', '5', '5', '2024-03-01', NULL, '2026-04-19 13:31:46'),
('5', '6', '5', '2026-04-28', NULL, '2026-04-28 15:05:37'),
('6', '7', '5', '2026-04-28', NULL, '2026-04-28 17:47:44'),
('0', '0', '3', '2026-03-25', NULL, '2026-06-12 10:40:28');


-- Estrutura da tabela `funcionarios`
DROP TABLE IF EXISTS `funcionarios`;
CREATE TABLE `funcionarios` (
  `id` int(11) NOT NULL,
  `usuario_sistema_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `filial_id` int(11) NOT NULL,
  `departamento_id` int(11) DEFAULT NULL,
  `cargo_id` int(11) DEFAULT NULL,
  `matricula` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_social` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_pessoal` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `senha` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpf` varchar(14) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rg` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `telefone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `celular` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco` text COLLATE utf8mb4_unicode_ci,
  `numero` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_admissao` date NOT NULL,
  `data_demissao` date DEFAULT NULL,
  `tipo_contrato` enum('clt','pj','estagio','temporario') COLLATE utf8mb4_unicode_ci DEFAULT 'clt',
  `status` enum('ativo','ferias','licenca','desligado','afastado') COLLATE utf8mb4_unicode_ci DEFAULT 'ativo',
  `tipo_usuario` enum('admin','gestor','supervisor','funcionario') COLLATE utf8mb4_unicode_ci DEFAULT 'funcionario',
  `pode_gerenciar_filiais` tinyint(1) DEFAULT '0',
  `pode_gerenciar_funcionarios` tinyint(1) DEFAULT '0',
  `pode_ver_relatorios` tinyint(1) DEFAULT '0',
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `token_expires_at` datetime DEFAULT NULL,
  `last_api_use` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `funcionarios`
INSERT INTO `funcionarios` (`id`, `usuario_sistema_id`, `empresa_id`, `filial_id`, `departamento_id`, `cargo_id`, `matricula`, `nome`, `nome_social`, `email`, `email_pessoal`, `senha`, `cpf`, `rg`, `data_nascimento`, `telefone`, `celular`, `endereco`, `numero`, `complemento`, `bairro`, `cidade`, `estado`, `cep`, `data_admissao`, `data_demissao`, `tipo_contrato`, `status`, `tipo_usuario`, `pode_gerenciar_filiais`, `pode_gerenciar_funcionarios`, `pode_ver_relatorios`, `foto`, `created_by`, `created_at`, `updated_at`, `token_expires_at`, `last_api_use`, `deleted_at`) VALUES ('0', NULL, '0', '22', NULL, '6', '00189', 'ANA CAROLINA PORTELA NEVES', NULL, 'empresa@srodrigbues.com.br', 'carolsnows7@gmail.com', '$2y$10$tyg14DxJC3qDmDxBecEaSehLVeVHR6wlvjbCqUlfjuR5Z4dSte1A2', '170.738.277-85', NULL, '1994-07-25', NULL, NULL, 'Rua Gonçalves Ledo', '145', 'Cx 01', 'Granja Guarani', 'Teresópolis', 'RJ', '25960360', '2026-03-25', NULL, 'clt', 'ativo', 'funcionario', '0', '0', '0', NULL, '0', '2026-06-12 10:34:31', '2026-06-12 10:40:28', NULL, NULL, NULL);


-- Estrutura da tabela `jornadas`
DROP TABLE IF EXISTS `jornadas`;
CREATE TABLE `jornadas` (
  `id` int(11) NOT NULL,
  `filial_id` int(11) NOT NULL,
  `nome` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `segunda_inicio` time DEFAULT NULL,
  `segunda_fim` time DEFAULT NULL,
  `terca_inicio` time DEFAULT NULL,
  `terca_fim` time DEFAULT NULL,
  `quarta_inicio` time DEFAULT NULL,
  `quarta_fim` time DEFAULT NULL,
  `quinta_inicio` time DEFAULT NULL,
  `quinta_fim` time DEFAULT NULL,
  `sexta_inicio` time DEFAULT NULL,
  `sexta_fim` time DEFAULT NULL,
  `sabado_inicio` time DEFAULT NULL,
  `sabado_fim` time DEFAULT NULL,
  `domingo_inicio` time DEFAULT NULL,
  `domingo_fim` time DEFAULT NULL,
  `almoco_duracao` int(11) DEFAULT '60',
  `almoco_inicio` time DEFAULT NULL,
  `almoco_fim` time DEFAULT NULL,
  `carga_horaria_diaria` int(11) DEFAULT NULL,
  `carga_horaria_semanal` int(11) DEFAULT NULL,
  `horas_extras_percentual_50` int(11) DEFAULT '50',
  `horas_extras_percentual_100` int(11) DEFAULT '100',
  `banco_horas_ativo` tinyint(1) DEFAULT '0',
  `banco_horas_limite` int(11) DEFAULT '40',
  `banco_horas_validade_meses` int(11) DEFAULT '6',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `jornadas`
INSERT INTO `jornadas` (`id`, `filial_id`, `nome`, `descricao`, `segunda_inicio`, `segunda_fim`, `terca_inicio`, `terca_fim`, `quarta_inicio`, `quarta_fim`, `quinta_inicio`, `quinta_fim`, `sexta_inicio`, `sexta_fim`, `sabado_inicio`, `sabado_fim`, `domingo_inicio`, `domingo_fim`, `almoco_duracao`, `almoco_inicio`, `almoco_fim`, `carga_horaria_diaria`, `carga_horaria_semanal`, `horas_extras_percentual_50`, `horas_extras_percentual_100`, `banco_horas_ativo`, `banco_horas_limite`, `banco_horas_validade_meses`, `created_at`) VALUES ('1', '1', 'Comercial - 8h', NULL, '08:00:00', '18:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '60', NULL, NULL, NULL, '440', '50', '100', '0', '40', '6', '2026-04-19 13:31:46'),
('2', '1', 'Administrativo - 6h', NULL, '09:00:00', '17:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '60', NULL, NULL, NULL, '360', '50', '100', '0', '40', '6', '2026-04-19 13:31:46'),
('3', '2', 'Loja - 8h', NULL, '09:00:00', '19:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '60', NULL, NULL, NULL, '440', '50', '100', '0', '40', '6', '2026-04-19 13:31:46'),
('4', '3', 'Loja - 8h', NULL, '09:00:00', '19:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '60', NULL, NULL, NULL, '440', '50', '100', '0', '40', '6', '2026-04-19 13:31:46'),
('5', '4', 'Escritório - 8h', NULL, '08:00:00', '17:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '60', NULL, NULL, NULL, '440', '50', '100', '0', '40', '6', '2026-04-19 13:31:46');


-- Estrutura da tabela `logs_auditoria`
DROP TABLE IF EXISTS `logs_auditoria`;
CREATE TABLE `logs_auditoria` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `usuario_nome` varchar(100) DEFAULT NULL,
  `usuario_email` varchar(100) DEFAULT NULL,
  `usuario_tipo` varchar(50) DEFAULT NULL,
  `acao` enum('INSERT','UPDATE','DELETE','LOGIN','LOGOUT','VIEW','EXPORT','BACKUP','RESTORE') NOT NULL,
  `modulo` varchar(50) NOT NULL,
  `registro_id` int(11) DEFAULT NULL,
  `descricao` text,
  `dados_anteriores` text,
  `dados_novos` text,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados da tabela `logs_auditoria`
INSERT INTO `logs_auditoria` (`id`, `usuario_id`, `usuario_nome`, `usuario_email`, `usuario_tipo`, `acao`, `modulo`, `registro_id`, `descricao`, `dados_anteriores`, `dados_novos`, `ip_address`, `user_agent`, `created_at`) VALUES ('1', '8', 'By Bicos', 'atendimento@bybicos.com.br', 'admin_empresa', 'LOGIN', 'login', '8', 'Login de teste - auditoria', NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0', '2026-05-18 14:13:41'),
('2', '8', 'By Bicos', 'atendimento@bybicos.com.br', 'admin_empresa', 'INSERT', 'funcionarios', '999', 'Inserção de teste', NULL, '{\"nome\":\"Usuario Teste\",\"email\":\"teste@teste.com\"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0', '2026-05-18 14:13:45'),
('3', '8', 'By Bicos', 'atendimento@bybicos.com.br', 'admin_empresa', 'UPDATE', 'funcionarios', '999', 'Atualização de teste', '{\"nome\":\"Nome Antigo\",\"email\":\"antigo@teste.com\"}', '{\"nome\":\"Nome Novo\",\"email\":\"novo@teste.com\"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0', '2026-05-18 14:13:47'),
('4', '8', 'By Bicos', 'atendimento@bybicos.com.br', 'admin_empresa', 'DELETE', 'funcionarios', '999', 'Remoção de teste', '{\"nome\":\"Usuario Removido\",\"email\":\"remove@teste.com\"}', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0', '2026-05-18 14:13:48'),
('5', '8', 'By Bicos', 'atendimento@bybicos.com.br', 'admin_empresa', 'EXPORT', 'relatorios', NULL, 'Exportou relatório para Excel', NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0', '2026-05-18 14:13:51');


-- Estrutura da tabela `logs_biometricos`
DROP TABLE IF EXISTS `logs_biometricos`;
CREATE TABLE `logs_biometricos` (
  `id` int(11) NOT NULL,
  `funcionario_id` int(11) DEFAULT NULL,
  `sucesso` tinyint(1) DEFAULT '0',
  `score` decimal(5,4) DEFAULT NULL,
  `tempo_resposta_ms` int(11) DEFAULT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `logs_biometricos`

-- Estrutura da tabela `logs_sistema`
DROP TABLE IF EXISTS `logs_sistema`;
CREATE TABLE `logs_sistema` (
  `id` int(11) NOT NULL,
  `funcionario_id` int(11) DEFAULT NULL,
  `acao` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tabela_afetada` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registro_id` int(11) DEFAULT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `logs_sistema`
INSERT INTO `logs_sistema` (`id`, `funcionario_id`, `acao`, `tabela_afetada`, `registro_id`, `descricao`, `ip`, `user_agent`, `created_at`) VALUES ('1', '1', 'LOGIN', 'funcionarios', '1', 'Usuário fez login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-19 13:45:26'),
('2', '1', 'INSERT', 'pontos', '9', 'Registrou ponto: entrada', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-19 13:53:43'),
('3', '1', 'LOGOUT', 'funcionarios', '1', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-20 18:56:50'),
('4', '1', 'LOGIN', 'funcionarios', '1', 'Usuário fez login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-20 18:57:03'),
('5', '1', 'INSERT', 'solicitacoes', '1', 'Criou solicitação de abono', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-20 21:19:22'),
('6', '1', 'INSERT', 'pontos', '10', 'Registrou ponto: entrada', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-21 10:06:47'),
('7', '1', 'LOGOUT', 'funcionarios', '1', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-21 10:06:57'),
('8', '1', 'LOGIN', 'funcionarios', '1', 'Usuário fez login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-21 10:09:10'),
('9', '1', 'INSERT', 'pontos', '11', 'Registrou ponto: saida_almoco', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-21 13:00:02'),
('10', '1', 'INSERT', 'pontos', '12', 'Registrou ponto: volta_almoco', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-21 14:18:52'),
('11', '1', 'LOGOUT', 'funcionarios', '1', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-23 13:57:03'),
('12', '1', 'LOGIN', 'funcionarios', '1', 'Login na empresa: Empresa', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-24 09:36:59'),
('13', '1', 'LOGOUT', 'funcionarios', '1', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-24 09:37:01'),
('14', '1', 'LOGIN', 'funcionarios', '1', 'Login na empresa: Empresa', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-24 09:37:12'),
('15', '1', 'LOGOUT', 'funcionarios', '1', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-24 09:38:47'),
('16', '1', 'LOGIN', 'funcionarios', '1', 'Login na empresa: Empresa', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-26 15:15:30'),
('17', '1', 'LOGOUT', 'funcionarios', '1', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-26 15:22:30'),
('18', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-26 15:28:34'),
('19', '1', 'LOGOUT', 'funcionarios', '1', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-26 15:29:10'),
('20', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-26 16:38:16'),
('21', '1', 'LOGOUT', 'funcionarios', '1', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-26 17:11:44'),
('22', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-26 17:11:55'),
('23', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-26 17:15:13'),
('24', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-26 17:16:38'),
('25', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-26 18:02:37'),
('26', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-26 18:02:49'),
('27', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-26 18:36:55'),
('28', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-26 18:37:19'),
('29', '3', 'CADASTRO_EMPRESA', NULL, NULL, 'Cadastrou empresa: Divulgonline', '::1', NULL, '2026-04-26 18:42:17'),
('30', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-26 18:42:33'),
('31', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-26 18:46:24'),
('32', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-26 18:53:33'),
('33', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-26 18:54:01'),
('34', '1', 'LOGOUT', 'funcionarios', '1', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-27 12:03:09'),
('35', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-27 12:03:29'),
('36', '3', 'CADASTRO_EMPRESA', NULL, NULL, 'Cadastrou empresa: divulgonline', '::1', NULL, '2026-04-28 09:20:03'),
('37', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-28 09:20:43'),
('38', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-28 09:27:18'),
('39', '3', 'CADASTRO_EMPRESA', NULL, NULL, 'Cadastrou empresa: Divulgonline', '::1', NULL, '2026-04-28 09:28:11'),
('40', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-28 09:29:25'),
('47', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-28 16:42:41'),
('48', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-28 16:43:20'),
('53', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-28 17:18:00'),
('54', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-28 17:44:53'),
('56', '7', 'INSERT', 'funcionarios', '7', 'Cadastrou funcionário: Simone Leite de Freitas', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-28 17:47:44'),
('57', '7', 'LOGOUT', 'funcionarios', '7', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-28 17:47:48'),
('58', '7', 'LOGIN', 'usuarios_sistema', '7', 'Login realizado: divulgonlinebrasil@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-28 17:48:11'),
('59', '7', 'LOGOUT', 'funcionarios', '7', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-28 17:48:48'),
('60', '7', 'LOGIN', 'usuarios_sistema', '7', 'Login realizado: divulgonlinebrasil@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-28 17:49:22'),
('61', '7', 'LOGOUT', 'funcionarios', '7', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 14:34:01'),
('62', '7', 'LOGIN', 'usuarios_sistema', '7', 'Login realizado: divulgonlinebrasil@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 14:34:34'),
('63', '7', 'LOGOUT', 'funcionarios', '7', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 14:35:22'),
('64', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 14:35:34'),
('65', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 14:37:48'),
('66', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 14:38:36'),
('67', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 14:42:18'),
('68', '7', 'LOGIN', 'usuarios_sistema', '7', 'Login realizado: backupclaudenir@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 14:42:34'),
('69', '7', 'LOGOUT', 'funcionarios', '7', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 14:44:53'),
('70', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 14:45:08'),
('71', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 16:25:30'),
('72', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 16:28:55'),
('73', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 16:41:53'),
('76', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 17:02:30'),
('77', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 17:02:52'),
('78', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 17:03:41'),
('79', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 17:04:41'),
('80', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 17:05:14'),
('81', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 17:05:39'),
('82', '7', 'LOGIN', 'usuarios_sistema', '7', 'Login realizado: backupclaudenir@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 17:06:05'),
('83', '7', 'LOGOUT', 'funcionarios', '7', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-29 17:35:50'),
('86', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 10:34:54'),
('87', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 11:07:12'),
('92', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 11:11:08'),
('93', '3', 'EXCLUIR_EMPRESA', NULL, NULL, 'Empresa excluída: Teste', '::1', NULL, '2026-04-30 11:11:41'),
('94', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 11:11:46'),
('95', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 11:12:40'),
('96', '3', 'EXCLUIR_EMPRESA', NULL, NULL, 'Empresa excluída: Teste', '::1', NULL, '2026-04-30 11:16:44'),
('97', '3', 'RECUPERAR_EMPRESA', NULL, NULL, 'Empresa recuperada: Teste (ID original: 7)', '::1', NULL, '2026-04-30 11:17:08'),
('98', '3', 'EXCLUIR_EMPRESA', NULL, NULL, 'Empresa excluída: Teste', '::1', NULL, '2026-04-30 11:34:03'),
('99', '3', 'RECUPERAR_EMPRESA', NULL, NULL, 'Empresa recuperada: Teste (ID original: 8)', '::1', NULL, '2026-04-30 11:34:14'),
('100', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 14:19:13'),
('101', '7', 'LOGIN', 'usuarios_sistema', '7', 'Login realizado: backupclaudenir@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 14:21:52'),
('102', '7', 'LOGOUT', 'funcionarios', '7', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 16:34:34'),
('103', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 16:34:49'),
('104', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 16:35:17'),
('105', '7', 'LOGIN', 'usuarios_sistema', '7', 'Login realizado: backupclaudenir@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 16:37:07'),
('106', '7', 'LOGOUT', 'funcionarios', '7', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 16:38:44'),
('111', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 16:43:18'),
('112', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 16:45:59'),
('113', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 16:47:00'),
('114', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 16:48:57'),
('115', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 16:49:40'),
('116', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 16:50:34'),
('117', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 16:51:15'),
('118', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-30 17:38:45'),
('121', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-04 10:00:33'),
('122', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-04 10:01:51'),
('125', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-04 11:53:23'),
('126', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 11:46:15'),
('130', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 12:16:24'),
('131', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 12:17:29'),
('139', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 15:08:58'),
('140', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 15:11:25'),
('145', '7', 'LOGIN', 'usuarios_sistema', '7', 'Login realizado: backupclaudenir@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 15:18:50'),
('146', '7', 'LOGOUT', 'funcionarios', '7', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 15:19:00'),
('149', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 15:22:13'),
('150', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 15:27:15'),
('154', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 16:05:25'),
('155', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 16:05:35'),
('168', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 16:22:18'),
('169', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 16:25:18'),
('170', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 16:28:59'),
('171', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 16:29:16'),
('174', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 16:30:12'),
('175', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 16:35:39'),
('176', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 16:36:20'),
('177', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 16:37:58'),
('178', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 16:38:12'),
('179', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 16:41:51'),
('180', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 16:42:03'),
('181', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 17:22:38'),
('184', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 17:25:52'),
('185', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-05 17:27:51'),
('187', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-05 19:22:01'),
('188', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-05 19:22:09'),
('191', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-05 19:38:09'),
('192', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-05 19:41:22'),
('193', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-05 19:41:37'),
('194', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-05-05 19:42:17'),
('195', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-05-05 19:42:24'),
('198', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-05-05 19:51:30'),
('199', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-05 20:13:38'),
('202', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-05 21:11:12'),
('203', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-05 21:39:48'),
('207', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-05-05 23:45:47'),
('208', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-05-05 23:46:56'),
('209', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-05-05 23:55:46'),
('210', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-05-05 23:56:00'),
('211', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-05-06 00:01:51'),
('212', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-05-06 00:02:07'),
('213', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-05-06 00:03:05'),
('214', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-05-06 00:03:30'),
('215', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-05-06 00:03:56'),
('216', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-05-06 00:04:31'),
('217', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-05-06 00:08:38'),
('218', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 10:34:17'),
('219', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 10:35:34'),
('220', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 10:35:55'),
('221', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 10:37:50'),
('222', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 10:38:10'),
('223', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 11:01:38'),
('224', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 11:15:57'),
('225', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 11:20:21'),
('226', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 11:20:35'),
('227', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 11:25:18'),
('228', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 11:25:35'),
('229', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 11:26:45'),
('230', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 11:29:50'),
('231', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 11:36:35'),
('232', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 11:36:49'),
('233', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 11:43:56'),
('234', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 11:44:08'),
('235', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 11:54:05'),
('236', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 12:01:47'),
('237', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 12:05:18'),
('238', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 12:07:53'),
('239', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 12:09:10'),
('240', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 12:13:52'),
('241', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 12:14:54'),
('242', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 12:15:07'),
('243', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 12:15:47'),
('244', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 12:16:03'),
('245', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 12:28:57'),
('246', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 12:29:16'),
('247', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 12:30:35'),
('248', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 12:30:44'),
('249', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 12:41:59'),
('250', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 12:42:10'),
('251', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 12:44:12'),
('252', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 12:53:37'),
('253', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 14:28:43'),
('254', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 14:28:56'),
('255', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 15:06:39'),
('256', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 15:06:54'),
('258', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 15:29:34'),
('259', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-06 15:29:57'),
('265', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-06 18:48:13'),
('266', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-06 18:52:00'),
('267', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-06 18:52:19'),
('268', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-06 18:52:32'),
('273', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-06 19:21:42'),
('275', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-07 09:33:32'),
('276', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-05-07 09:55:55'),
('279', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-07 18:55:41'),
('280', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-07 18:56:03'),
('281', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0', '2026-05-18 09:06:13'),
('282', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0', '2026-05-18 19:18:46'),
('283', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0', '2026-05-20 12:21:03'),
('284', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0', '2026-05-21 09:40:34'),
('285', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0', '2026-05-22 08:44:04'),
('286', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0', '2026-05-25 23:52:48'),
('287', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0', '2026-05-25 23:53:05'),
('288', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0', '2026-05-25 23:53:53'),
('289', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionário: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-05-26 15:56:51'),
('290', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionario: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0', '2026-05-29 17:16:52'),
('291', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionario: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-05-29 17:23:27'),
('292', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0', '2026-05-29 17:30:15'),
('293', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0', '2026-05-29 17:30:47'),
('294', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0', '2026-05-29 17:30:53'),
('297', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-05-29 17:32:42'),
('298', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionario: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-05-29 17:32:56'),
('302', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionario: testeclau@gmail.com', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-05-29 17:57:01'),
('304', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-05-29 20:45:37'),
('305', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionario: testeclau@gmail.com', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-01 09:06:13'),
('306', '14', 'LOGOUT', 'funcionarios', '14', 'Usuário fez logout', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-01 09:40:26'),
('307', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-01 09:41:01'),
('308', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-01 09:42:32'),
('309', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-01 09:43:05'),
('310', '3', 'LOGOUT', 'funcionarios', '3', 'Usuário fez logout', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-01 09:43:45'),
('311', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-01 09:44:21'),
('312', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionario: testeclau@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-09 10:53:18'),
('313', '14', 'LOGOUT', 'funcionarios', '14', 'Usuario fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-09 11:09:51'),
('314', '14', 'LOGOUT', 'funcionarios', '14', 'Usuario fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-09 11:25:23'),
('315', '3', 'LOGOUT', 'funcionarios', '3', 'Usuario fez logout', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-09 11:31:12'),
('318', '14', 'LOGOUT', 'funcionarios', '14', 'Usuario fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-09 11:50:24'),
('322', '14', 'LOGOUT', 'funcionarios', '14', 'Usuario fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-09 12:14:13'),
('325', '14', 'LOGOUT', 'funcionarios', '14', 'Usuario fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-09 16:35:38'),
('326', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionario: testeclau@gmail.com', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-10 08:57:03'),
('327', '14', 'LOGOUT', 'funcionarios', '14', 'Usuario fez logout', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-10 08:57:14'),
('328', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionario: testeclau@gmail.com', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-10 09:55:14'),
('329', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-10 10:26:32'),
('330', '3', 'LOGOUT', 'funcionarios', '3', 'Usuario fez logout', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-10 12:03:28'),
('0', '8', 'LOGIN', 'usuarios_sistema', '8', 'Login realizado: atendimento@bybicos.com.br', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-10 17:37:27'),
('0', '8', 'LOGOUT', 'funcionarios', '8', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-10 17:37:34'),
('0', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionario: testeclau@gmail.com', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-10 17:38:46'),
('0', '14', 'LOGOUT', 'funcionarios', '14', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-10 17:47:24'),
('0', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-10 17:47:40'),
('0', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '191.57.28.253', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-10 18:40:36'),
('0', '3', 'LOGOUT', 'funcionarios', '3', 'Usuario fez logout', '191.57.28.253', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-10 18:44:08'),
('0', '0', 'LOGOUT', 'funcionarios', '0', 'Usuario fez logout', '191.57.28.253', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-10 18:50:24'),
('0', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '191.57.28.253', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-10 19:00:34'),
('0', '3', 'INSERT', 'filiais', '0', 'Cadastrou filial: Silmar Rodrigues Junior', '191.57.28.253', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-10 19:10:03'),
('0', '3', 'LOGOUT', 'funcionarios', '3', 'Usuario fez logout', '191.57.28.253', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-10 19:10:07'),
('0', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '191.57.28.253', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-10 19:11:12'),
('0', '3', 'LOGOUT', 'funcionarios', '3', 'Usuario fez logout', '191.57.28.253', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-10 19:11:40'),
('0', '0', 'LOGIN', 'usuarios_sistema', '0', 'Login realizado: silmar_jr@yahoo.com.br', '191.57.28.253', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-10 19:11:57'),
('0', '0', 'LOGIN', 'usuarios_sistema', '0', 'Login realizado: silmar_jr@yahoo.com.br', '191.57.28.253', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36', '2026-06-10 19:13:09'),
('0', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '191.57.28.253', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '2026-06-10 19:32:20'),
('0', '3', 'LOGOUT', 'funcionarios', '3', 'Usuario fez logout', '191.57.28.253', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '2026-06-10 19:32:43'),
('0', '0', 'LOGIN', 'usuarios_sistema', '0', 'Login realizado: silmar_jr@yahoo.com.br', '191.57.28.253', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '2026-06-10 19:34:53'),
('0', '0', 'INSERT', 'filiais', '0', 'Cadastrou filial: Estação do Lanche', '191.57.28.253', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '2026-06-10 19:47:20'),
('0', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionario: testeclau@gmail.com', '177.131.167.146', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36', '2026-06-10 22:11:22'),
('0', '14', 'LOGOUT', 'funcionarios', '14', 'Usuario fez logout', '177.131.167.146', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36', '2026-06-10 22:16:39'),
('0', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '177.131.167.146', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '2026-06-10 22:24:57'),
('0', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionario: testeclau@gmail.com', '187.16.241.8', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36', '2026-06-11 07:38:20'),
('0', '14', 'LOGOUT', 'funcionarios', '14', 'Usuario fez logout', '187.16.241.8', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36', '2026-06-11 07:39:24'),
('0', '8', 'LOGIN', 'usuarios_sistema', '8', 'Login realizado: atendimento@bybicos.com.br', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-11 08:42:13'),
('0', '8', 'LOGOUT', 'funcionarios', '8', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-11 08:42:40'),
('0', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-11 09:37:53'),
('0', '3', 'LOGOUT', 'funcionarios', '3', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-11 09:41:13'),
('0', '0', 'LOGIN', 'usuarios_sistema', '0', 'Login realizado: silmar_jr@yahoo.com.br', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-11 09:41:56'),
('0', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-11 17:10:58'),
('0', '3', 'LOGOUT', 'funcionarios', '3', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-11 17:11:00'),
('0', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-11 17:13:59'),
('0', '3', 'LOGOUT', 'funcionarios', '3', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-11 17:14:48'),
('0', '0', 'LOGIN', 'usuarios_sistema', '0', 'Login realizado: silmar_jr@yahoo.com.br', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-11 17:15:11'),
('0', '14', 'LOGIN', 'funcionarios', '14', 'Login funcionario: testeclau@gmail.com', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 07:52:07'),
('0', '14', 'LOGOUT', 'funcionarios', '14', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 07:52:15'),
('0', '8', 'LOGIN', 'usuarios_sistema', '8', 'Login realizado: atendimento@bybicos.com.br', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 07:52:33'),
('0', '8', 'LOGOUT', 'funcionarios', '8', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 07:54:32'),
('0', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-12 08:03:17'),
('0', '3', 'LOGOUT', 'funcionarios', '3', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-12 08:07:04'),
('0', '0', 'LOGIN', 'usuarios_sistema', '0', 'Login realizado: silmar_jr@yahoo.com.br', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-12 08:09:18'),
('0', '0', 'LOGOUT', 'funcionarios', '0', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-12 08:09:26'),
('0', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-12 08:10:14'),
('0', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 08:40:48'),
('0', '3', 'LOGOUT', 'funcionarios', '3', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 08:41:29'),
('0', '0', 'LOGIN', 'usuarios_sistema', '0', 'Login realizado: silmar_jr@yahoo.com.br', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 08:41:58'),
('0', '0', 'INSERT', 'filiais', '0', 'Cadastrou filial: ELY SANTOS RODRIGUES', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 08:55:32'),
('0', '0', 'LOGOUT', 'funcionarios', '0', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 09:56:24'),
('0', '0', 'LOGIN', 'usuarios_sistema', '0', 'Login realizado: silmar_jr@yahoo.com.br', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 09:57:45'),
('0', '0', 'LOGOUT', 'funcionarios', '0', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 10:07:35'),
('0', '0', 'LOGIN', 'usuarios_sistema', '0', 'Login realizado: silmar_jr@yahoo.com.br', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 10:08:09'),
('0', '0', 'INSERT', 'funcionarios', '0', 'Cadastrou funcionário: ANA CAROLINA PORTELA NEVES', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 10:34:31'),
('0', '0', 'LOGOUT', 'funcionarios', '0', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 10:36:41'),
('0', '0', 'LOGIN', 'usuarios_sistema', '0', 'Login realizado: silmar_jr@yahoo.com.br', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 10:37:57'),
('0', '0', 'UPDATE', 'funcionarios', '0', 'Editou funcionário: ANA CAROLINA PORTELA NEVES', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 10:40:28'),
('0', '0', 'LOGOUT', 'funcionarios', '0', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 10:53:14'),
('0', '0', 'LOGIN', 'usuarios_sistema', '0', 'Login realizado: silmar_jr@yahoo.com.br', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 10:53:29'),
('0', '0', 'LOGOUT', 'funcionarios', '0', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 10:56:59'),
('0', '8', 'LOGIN', 'usuarios_sistema', '8', 'Login realizado: atendimento@bybicos.com.br', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 10:57:24'),
('0', '8', 'LOGOUT', 'funcionarios', '8', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 11:00:05'),
('0', '9', 'LOGIN', 'usuarios_sistema', '9', 'Login realizado: silmar_jr@yahoo.com.br', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 11:00:56'),
('0', '9', 'LOGOUT', 'funcionarios', '9', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 11:07:23'),
('0', '9', 'LOGIN', 'usuarios_sistema', '9', 'Login realizado: silmar_jr@yahoo.com.br', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 11:10:34'),
('0', '9', 'LOGOUT', 'funcionarios', '9', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 11:15:46'),
('0', '9', 'LOGIN', 'usuarios_sistema', '9', 'Login realizado: silmar_jr@yahoo.com.br', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-12 11:16:30'),
('0', '3', 'LOGOUT', 'funcionarios', '3', 'Usuario fez logout', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-12 11:25:01'),
('0', '3', 'LOGIN', 'usuarios_sistema', '3', 'Login realizado: superadmin@pontofacil.com', '138.204.67.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0', '2026-06-12 11:25:33');


-- Estrutura da tabela `notificacoes`
DROP TABLE IF EXISTS `notificacoes`;
CREATE TABLE `notificacoes` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `funcionario_id` int(11) DEFAULT NULL,
  `tipo` enum('sistema','ponto','solicitacao','alerta','lembrete') DEFAULT 'sistema',
  `titulo` varchar(200) NOT NULL,
  `mensagem` text NOT NULL,
  `link` varchar(500) DEFAULT NULL,
  `icone` varchar(50) DEFAULT NULL,
  `cor` varchar(20) DEFAULT 'primary',
  `lida` tinyint(4) DEFAULT '0',
  `data_leitura` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados da tabela `notificacoes`

-- Estrutura da tabela `notificacoes_config`
DROP TABLE IF EXISTS `notificacoes_config`;
CREATE TABLE `notificacoes_config` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `notificar_ponto` bit(1) DEFAULT b'1',
  `notificar_ponto_lembrete` bit(1) DEFAULT b'1',
  `notificar_ponto_facial` bit(1) DEFAULT b'1',
  `notificar_solicitacao` bit(1) DEFAULT b'1',
  `notificar_aprovacao` bit(1) DEFAULT b'1',
  `notificar_sistema` bit(1) DEFAULT b'1',
  `notificar_atraso` bit(1) DEFAULT b'1',
  `lembretes_email` bit(1) DEFAULT b'0',
  `lembrete_entrada` time DEFAULT '07:45:00',
  `lembrete_almoco` time DEFAULT '11:45:00',
  `lembrete_saida` time DEFAULT '17:45:00',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados da tabela `notificacoes_config`
INSERT INTO `notificacoes_config` (`id`, `usuario_id`, `notificar_ponto`, `notificar_ponto_lembrete`, `notificar_ponto_facial`, `notificar_solicitacao`, `notificar_aprovacao`, `notificar_sistema`, `notificar_atraso`, `lembretes_email`, `lembrete_entrada`, `lembrete_almoco`, `lembrete_saida`, `created_at`, `updated_at`) VALUES ('1', '3', '1', '1', '1', '1', '1', '1', '1', '0', '07:45:00', '11:45:00', '17:45:00', '2026-05-07 16:19:58', '2026-05-07 16:19:58'),
('2', '7', '1', '1', '1', '1', '1', '1', '1', '0', '07:45:00', '11:45:00', '17:45:00', '2026-05-07 16:19:58', '2026-05-07 16:19:58'),
('3', '8', '1', '1', '1', '1', '1', '1', '1', '0', '07:45:00', '11:45:00', '17:45:00', '2026-05-07 16:19:58', '2026-05-07 16:19:58');


-- Estrutura da tabela `planos`
DROP TABLE IF EXISTS `planos`;
CREATE TABLE `planos` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `preco_mensal` decimal(10,2) NOT NULL,
  `preco_anual` decimal(10,2) DEFAULT NULL,
  `recurso_funcionarios` int(11) DEFAULT '0',
  `recurso_filiais` int(11) DEFAULT '0',
  `recurso_departamentos` tinyint(1) DEFAULT '0',
  `recurso_horas_extras` tinyint(1) DEFAULT '0',
  `recurso_banco_horas` tinyint(1) DEFAULT '0',
  `recurso_justificativas` tinyint(1) DEFAULT '0',
  `recurso_relatorios_avancados` tinyint(1) DEFAULT '0',
  `recurso_multi_gestores` tinyint(1) DEFAULT '0',
  `recurso_qrcode` tinyint(1) DEFAULT '0',
  `recurso_exportacao_excel` tinyint(1) DEFAULT '0',
  `recurso_exportacao_pdf` tinyint(1) DEFAULT '0',
  `recurso_backup` tinyint(1) DEFAULT '0',
  `recurso_api` tinyint(1) DEFAULT '0',
  `recurso_suporte_prioritario` tinyint(1) DEFAULT '0',
  `ordem` int(11) DEFAULT '0',
  `ativo` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `planos`
INSERT INTO `planos` (`id`, `nome`, `slug`, `descricao`, `preco_mensal`, `preco_anual`, `recurso_funcionarios`, `recurso_filiais`, `recurso_departamentos`, `recurso_horas_extras`, `recurso_banco_horas`, `recurso_justificativas`, `recurso_relatorios_avancados`, `recurso_multi_gestores`, `recurso_qrcode`, `recurso_exportacao_excel`, `recurso_exportacao_pdf`, `recurso_backup`, `recurso_api`, `recurso_suporte_prioritario`, `ordem`, `ativo`, `created_at`, `updated_at`) VALUES ('1', 'Básico', 'basico', NULL, '59.00', '601.80', '10', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '1', '2026-04-26 16:13:40', '2026-04-26 16:13:40'),
('2', 'Profissional', 'profissional', NULL, '89.00', '907.80', '30', '0', '1', '1', '0', '0', '1', '0', '1', '1', '0', '0', '0', '0', '2', '1', '2026-04-26 16:13:40', '2026-04-26 16:13:40'),
('3', 'Empresarial', 'empresarial', NULL, '189.00', '1927.80', '100', '0', '1', '1', '0', '0', '1', '1', '1', '1', '0', '0', '0', '1', '3', '1', '2026-04-26 16:13:40', '2026-04-26 16:13:40');


-- Estrutura da tabela `pontos`
DROP TABLE IF EXISTS `pontos`;
CREATE TABLE `pontos` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `funcionario_id` int(11) NOT NULL,
  `filial_id` int(11) NOT NULL,
  `tipo` enum('entrada','saida_almoco','volta_almoco','saida','extra_entrada','extra_saida') COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_hora` datetime NOT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `endereco_registro` text COLLATE utf8mb4_unicode_ci,
  `sincronizado` tinyint(1) DEFAULT '0',
  `origem` enum('app','web','totem','api') COLLATE utf8mb4_unicode_ci DEFAULT 'web',
  `justificativa` text COLLATE utf8mb4_unicode_ci,
  `aprovado_por` int(11) DEFAULT NULL,
  `status_aprovacao` enum('pendente','aprovado','rejeitado') COLLATE utf8mb4_unicode_ci DEFAULT 'aprovado',
  `observacao` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `foto_facial` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `pontos`
INSERT INTO `pontos` (`id`, `empresa_id`, `funcionario_id`, `filial_id`, `tipo`, `data_hora`, `latitude`, `longitude`, `endereco_registro`, `sincronizado`, `origem`, `justificativa`, `aprovado_por`, `status_aprovacao`, `observacao`, `created_at`, `ip_address`, `user_agent`, `foto_facial`) VALUES ('21', NULL, '14', '5', 'entrada', '2026-05-06 19:21:50', NULL, NULL, NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-06 19:21:50', NULL, NULL, 'uploads/pontos_facial/14_20260507_002150.jpg'),
('22', NULL, '14', '5', 'entrada', '2026-05-07 09:56:02', NULL, NULL, NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-07 09:56:02', NULL, NULL, 'uploads/pontos_facial/14_20260507_145602.jpg'),
('23', NULL, '14', '5', 'saida_almoco', '2026-05-07 11:58:50', NULL, NULL, NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-07 11:58:50', NULL, NULL, 'uploads/pontos_facial/14_20260507_165850.jpg'),
('24', NULL, '14', '5', 'volta_almoco', '2026-05-07 14:35:23', NULL, NULL, NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-07 14:35:23', NULL, NULL, 'uploads/pontos_facial/14_20260507_193523.jpg'),
('25', NULL, '14', '5', 'saida', '2026-05-07 18:56:33', '-22.43837250', '-42.96969400', NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-07 18:56:33', NULL, NULL, 'uploads/pontos_facial/14_20260507_235633.jpg'),
('26', NULL, '14', '5', 'entrada', '2026-05-16 13:58:17', '-22.52300000', '-41.93700000', NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-16 13:58:17', NULL, NULL, 'uploads/pontos_facial/14_20260516_185817.jpg'),
('27', NULL, '14', '5', 'entrada', '2026-05-18 09:06:19', '-22.44078570', '-42.97810732', NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-18 09:06:19', NULL, NULL, 'uploads/pontos_facial/14_20260518_140619.jpg'),
('28', NULL, '14', '5', 'saida_almoco', '2026-05-18 14:11:29', '-22.44078570', '-42.97810732', NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-18 14:11:29', NULL, NULL, 'uploads/pontos_facial/14_20260518_191129.jpg'),
('29', NULL, '14', '5', 'volta_almoco', '2026-05-18 15:27:13', '-22.44072675', '-42.97812387', NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-18 15:27:13', NULL, NULL, 'uploads/pontos_facial/14_20260518_202713.jpg'),
('30', NULL, '14', '5', 'saida', '2026-05-18 19:18:50', '-22.43833014', '-42.96974219', NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-18 19:18:50', NULL, NULL, 'uploads/pontos_facial/14_20260519_001850.jpg'),
('31', NULL, '14', '5', 'entrada', '2026-05-19 08:33:26', '-22.44083659', '-42.97800534', NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-19 08:33:26', NULL, NULL, 'uploads/pontos_facial/14_20260519_133326.jpg'),
('32', NULL, '14', '5', 'entrada', '2026-05-20 12:21:13', '-22.44071060', '-42.97814793', NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-20 12:21:13', NULL, NULL, 'uploads/pontos_facial/14_20260520_172113.jpg'),
('33', NULL, '14', '5', 'entrada', '2026-05-21 09:40:41', '-22.44070001', '-42.97812482', NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-21 09:40:41', NULL, NULL, 'uploads/pontos_facial/14_20260521_144041.jpg'),
('34', NULL, '14', '5', 'saida_almoco', '2026-05-21 14:29:59', '-22.44070001', '-42.97812482', NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-21 14:29:59', NULL, NULL, 'uploads/pontos_facial/14_20260521_192959.jpg'),
('35', NULL, '14', '5', 'volta_almoco', '2026-05-21 14:30:17', '-22.44080159', '-42.97810993', NULL, '0', 'web', NULL, NULL, 'aprovado', NULL, '2026-05-21 14:30:17', NULL, NULL, NULL),
('36', NULL, '14', '5', 'entrada', '2026-05-22 08:44:14', '-22.44077768', '-42.97809276', NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-22 08:44:14', NULL, NULL, 'uploads/pontos_facial/14_20260522_134414.jpg'),
('37', NULL, '14', '5', 'saida_almoco', '2026-05-22 12:06:20', '-22.44077933', '-42.97809194', NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-22 12:06:20', NULL, NULL, 'uploads/pontos_facial/14_20260522_170620.jpg'),
('38', NULL, '14', '5', 'entrada', '2026-05-25 08:20:51', '-22.44073801', '-42.97809885', NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-25 08:20:51', NULL, NULL, 'uploads/pontos_facial/14_20260525_132051.jpg'),
('39', NULL, '14', '5', 'saida_almoco', '2026-05-25 12:36:08', '-22.44073801', '-42.97809885', NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-25 12:36:08', NULL, NULL, 'uploads/pontos_facial/14_20260525_173608.jpg'),
('40', NULL, '14', '5', 'volta_almoco', '2026-05-25 14:30:34', '-22.44068581', '-42.97814694', NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-25 14:30:34', NULL, NULL, 'uploads/pontos_facial/14_20260525_193034.jpg'),
('41', NULL, '14', '5', 'saida', '2026-05-25 22:25:31', '-22.44071277', '-42.97815422', NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-25 22:25:31', NULL, NULL, 'uploads/pontos_facial/14_20260526_032531.jpg'),
('42', NULL, '14', '5', 'entrada', '2026-05-26 15:57:09', NULL, NULL, NULL, '0', '', NULL, NULL, 'aprovado', NULL, '2026-05-26 15:57:09', NULL, NULL, 'uploads/pontos_facial/14_20260526_205709.jpg');


-- Estrutura da tabela `sessoes_usuarios`
DROP TABLE IF EXISTS `sessoes_usuarios`;
CREATE TABLE `sessoes_usuarios` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `token_sessao` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `data_login` datetime NOT NULL,
  `data_ultima_atividade` datetime DEFAULT NULL,
  `status` enum('ativa','expirada','logout') COLLATE utf8mb4_unicode_ci DEFAULT 'ativa'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `sessoes_usuarios`

-- Estrutura da tabela `solicitacoes`
DROP TABLE IF EXISTS `solicitacoes`;
CREATE TABLE `solicitacoes` (
  `id` int(11) NOT NULL,
  `funcionario_id` int(11) NOT NULL,
  `empresa_id` int(11) DEFAULT '5',
  `filial_id` int(11) DEFAULT NULL,
  `tipo` varchar(50) NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `descricao` text NOT NULL,
  `data_inicio` date DEFAULT NULL,
  `data_fim` date DEFAULT NULL,
  `anexo` varchar(255) DEFAULT NULL,
  `status` enum('pendente','aprovado','rejeitado','cancelado') DEFAULT 'pendente',
  `resposta` text,
  `data_resposta` datetime DEFAULT NULL,
  `respondido_por` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados da tabela `solicitacoes`

-- Estrutura da tabela `tokens`
DROP TABLE IF EXISTS `tokens`;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL,
  `funcionario_id` int(11) NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('api','offline','recuperacao') COLLATE utf8mb4_unicode_ci DEFAULT 'api',
  `expira_em` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `tokens`

-- Estrutura da tabela `usuarios_sistema`
DROP TABLE IF EXISTS `usuarios_sistema`;
CREATE TABLE `usuarios_sistema` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senha` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('super_admin','admin_empresa','gestor','funcionario') COLLATE utf8mb4_unicode_ci DEFAULT 'funcionario',
  `empresa_id` int(11) DEFAULT NULL,
  `status` enum('ativo','inativo') COLLATE utf8mb4_unicode_ci DEFAULT 'ativo',
  `ultimo_acesso` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token_expires_at` datetime DEFAULT NULL,
  `last_api_use` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `usuarios_sistema`
INSERT INTO `usuarios_sistema` (`id`, `nome`, `email`, `senha`, `tipo`, `empresa_id`, `status`, `ultimo_acesso`, `created_at`, `token_expires_at`, `last_api_use`) VALUES ('3', 'Super Administrador', 'superadmin@pontofacil.com', '$2y$10$bBddBoRL/bCC.ZdwLbQ28uNztBN9StE6VZUGxQvTrlbWvBDqGf/la', 'super_admin', NULL, 'ativo', '2026-06-12 11:25:33', '2026-04-26 15:26:05', NULL, NULL),
('9', 'Silmar Rodrigues Junior', 'silmar_jr@yahoo.com.br', '$2y$10$4Fq/eTbkMsbw2jDWwEf62OYbrmRgQCuPdnSn4kxiq3fEQp7WLDZ1S', 'admin_empresa', '0', 'ativo', '2026-06-12 11:16:30', '2026-06-10 18:43:31', NULL, NULL);

SET FOREIGN_KEY_CHECKS=1;
